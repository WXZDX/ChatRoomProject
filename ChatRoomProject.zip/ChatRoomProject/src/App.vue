

<template>
   <div id="homepage" @click="jumpToHome">首页</div>

</template>

<script setup>
function jumpToHome(){
  window.location.href="/pages/Home/"
}
</script>

<style scoped>
/* 在组件的 <style> 部分或全局 CSS 文件中 */
.navi {
  background-color: #e0caca; /* 导航栏背景颜色 */
  color: white; /* 文字颜色 */
  display: flex; /* 使用 flex 布局 */
  justify-content: center; /* 内容居中 */
  align-items: center; /* 垂直居中 */
  padding: 10px 0; /* 上下内边距 */
  text-decoration: none; /* 去除下划线 */
}

.nav-link {
  color: rgb(255, 255, 255); /* 文字颜色 */
  padding: 0 15px; /* 左右内边距 */
 
  font-size: 16px; /* 字体大小 */
}

.nav-link:hover {
  background-color: #d2e5d1; /* 鼠标悬停时的背景颜色 */
}

.nav-link.router-link-active {
  background-color: #edd0d0; /* 激活状态的背景颜色 */
}
.homepage{
  font-size: 14px;
    color: #6a3636;
    width: 90%;
    display: flex;
    justify-content: right;
    padding-right: 10px;
    position: relative;
    bottom: 8px;
}
</style>