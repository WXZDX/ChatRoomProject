
import { createApp } from 'vue';
import Home from './Home.vue'

createApp(Home).mount('#home')