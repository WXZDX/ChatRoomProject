<template>
<h1>这是首页</h1>
</template> 
<script setup>
</script>
<style scoped>
</style>